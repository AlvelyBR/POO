﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Triangle : Shape
    {

        public Triangle(double alto, double ancho) : base(alto, ancho)
        {

            Ancho = ancho;
            Alto = alto;
        }
        public override double CalculateSurface()
        {
            return Alto * Ancho / 2;
        }
    }

}