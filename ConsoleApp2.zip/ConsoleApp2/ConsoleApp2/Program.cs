﻿
using System.Drawing;

namespace ConsoleApp2 { 
class Proyect
{
    static void Main(String[] args)
    {
        Shape triangulo = new Triangle(5.2, 7.6);
        Shape rectangulo = new Rectangle(6.9, 3.1);
        Shape circulo = new Circle(8,3);
        Shape[] figurasDiferentes = new Shape[3];

            figurasDiferentes[0] = triangulo;
            figurasDiferentes[1] = rectangulo;
            figurasDiferentes[2] = circulo;

        double[] shapesAreas = new double[3];

        for (int i = 0; i < 3; i++)
        {
            shapesAreas[i] = figurasDiferentes[i].CalculateSurface();
            Console.WriteLine("Se añadio el valor: " + i);
        }

        for (int i = 0; i < 3; i++)
        {
            Console.WriteLine("El area de la figura " + i + " es de: " + shapesAreas[i]);
        }
    }
}




public abstract class Shape
{
    public double Ancho;
    public double Alto;
    public Shape(double ancho, double alto)
    {
        this.Ancho = ancho;
        this.Alto = alto;
    }

    public abstract double CalculateSurface();

}
  
}
