﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia
{
    public class Curso
    {
        public string nombreCurso {  get; set; }
        public int recuentoClases { get; set; }
        public int recuentoEjercs { get; set; }

      
    }
}
